VaultCord — unauthenticated Discord OAuth token-exchange endpoints
Evidence archive, compiled 2026-11-01
Report: https://bugbase.ai/programs/vaultcord  (assets: api.vaultcord.com, wildcard row #2 "API Cluster")

WHAT IS IN THIS ARCHIVE
  raw/                     per-request captures. For each probe: <name>.hdr (response headers,
                           Set-Cookie/Cookie/Authorization lines removed by the reporter so the
                           archive contains no credentials of any kind), <name>.body (full response
                           body, unmodified), <name>.status (HTTP status code as printed by curl).
  VERIFICATION-2026-11-01.md   re-verification summary with the md5 comparison table.
  client_code/             three verbatim production chunks from https://dash.vaultcord.com
                           (importmap-resolved /__vc/<hash>.js), showing the client contract for
                           the two routes. Publicly served, unminified-beyond-build source.
  probe_log.txt            the probes that have no .status file, transcribed from the live terminal
                           output at the time of testing (statuses and md5 digests).

METHODOLOGY / CONSTRAINTS
  User-Agent: Mozilla/5.0 ResponsibleReporter Gecko/20100101   (exactly as required by the policy)
  All requests: GET only, single request per probe (no load or repeat-request testing),
  bogus/absent credential values only, no VaultCord account touched, no state-changing call,
  no other person's data or token, no internal addresses, no scanner used.
  The app-level WAF answers automated requests with a 403 "Verification Required" page; adding
  the browser-like Origin/Referer pair shown below makes the request behave like normal same-site
  traffic and is only about client-side tooling. No Cloudflare/WAF challenge was bypassed or
  automated at any point.

COMMANDS
  # differential (no Cookie, no Authorization, no X-Requested-With, no ETag)
  UA='Mozilla/5.0 ResponsibleReporter Gecko/20100101'
  for p in servers accounts/settings members/1/unauthed_members backups/refresh_token bot/public/refresh_token; do
    curl -sS -D probe.hdr -o probe.body -A "$UA" \
         -H 'Origin: https://dash.vaultcord.com' -H 'Referer: https://dash.vaultcord.com/' \
         "https://api.vaultcord.com/$p"
  done

  # token-shape variants + empty control
  for tok in 'mjabcdefghijklmnopqrstuvwx1234' \
             'mjabcdefghijklmnopqrstuvwxyzABCDEFG12345' \
             'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxIn0.abcdefghijklmnopqrstuvwxyz' \
             '0123456789abcdef0123456789abcdef0123'; do
    curl -sS -D probe.hdr -o probe.body -A "$UA" \
         -H 'Origin: https://dash.vaultcord.com' -H 'Referer: https://dash.vaultcord.com/' \
         -H "Authorization: $tok" 'https://api.vaultcord.com/bot/public/refresh_token'
  done
  # E6 = the same request with no -H 'Authorization:' at all (see probe_log.txt)

PROBE INDEX
  A1_nocookie_servers                GET /servers                     401  Authorization header missing
  A2_nocookie_accounts_settings      GET /accounts/settings           401  Authorization header missing
  A3_nocookie_backups_refresh        GET /backups/refresh_token       200  Discord API error: 400
  A4_nocookie_botpublic_refresh      GET /bot/public/refresh_token    200  Discord API error: 400
  C1_nocookie_members                GET /members/1/unauthed_members  401  Authorization header missing
  B1_empty_auth / B2_bogus_auth / B3_discord_shape_auth / B4_with_xrw_etag   200, same body
  D0_plain .. D4_amp_scope           upstream form-body injection attempts (2026-10-31) — all 200,
                                     byte-identical => no injection, no CRLF, claim retracted
  E2..E5 token shapes, E6 control    2026-11-01, all 200, md5 e445450bf56db2bb9cb0a96440159f6e

WHAT THE ARCHIVE DOES NOT SHOW
  It does not contain a successful token redemption. Capturing `success:true` with a real
  access_token requires a valid refresh token; per the program rules only the reporter's own
  credential may be used, and the reporter's dashboard session was logged out at the time of
  testing. No third-party token was sought or used. The proven defect is the missing
  authentication on an endpoint whose shipped client contract is credential redemption.
