# PoC — BridgeERC20V3 ERC20 entry accepts NATIVE_REPRESENTATION (KUB chain 96)

Demonstrates that the non-payable ERC20 entry
`bridge(address token_, uint256 amount_, uint64 destChainID_, DEST_TOKEN_TYPE)` does not reject
`token_ == NATIVE_REPRESENTATION`, so it spends the contract's OWN native and emits a
`Bridge(NATIVE, msg.sender, totalAmount, ...)` destination-credit event with zero value sent.

Runs entirely on a local fork of KUB mainnet (no live transaction is sent).

## Run
```bash
forge install foundry-rs/forge-std   # if lib/forge-std is absent
forge test -vv --match-test testNativeAcceptedByErc20Entry
```

## Expected
```
[PASS] testNativeAcceptedByErc20Entry()
  NATIVE_REPRESENTATION accepted by non-payable ERC20 entry; contract native spent; Bridge(credit) emitted for caller with zero value sent.
```

Target: BridgeERC20V3 0x89943b2499d678fb2d382C66b7BaeD00b732e753 (KUB 96 / identical verified source on Ethereum 1, solc 0.8.17).
